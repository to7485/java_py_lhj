package com.korea.layer.dto;

import lombok.Data;

@Data
public class TestDTO {

	private int id;
	private String message;
}
